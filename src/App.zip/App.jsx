import { useState } from 'react';
import './App.css'; // Ensure this file contains your external CSS styles

function App() {
  const [count, setCount] = useState(0);

  const applyNow = () => {
    alert("We are working on it");
    // Add redirection logic here
  };

  return (
    <div>
      <header style={headerStyle}>
        <h1>SalarySathi</h1>
        <p>Your Trusted Loan Partner</p>
      </header>

      <div style={contentStyle} id="about">
        <h2>About Us</h2>
        <p>
          Welcome to <strong>SalarySathi</strong>, your trusted partner in providing quick and hassle-free personal loans
          for salaried individuals. We simplify financial access, offering flexible loan options tailored to your needs.
        </p>
        <p>
          At SalarySathi, we are dedicated to empowering individuals and businesses by offering tailored solutions designed to meet your unique needs. Our mission is to help you achieve your personal and professional goals by providing effective tools and resources. Whether you're looking for guidance on managing your growth or scaling your business, we're here to support you every step of the way.
        </p>
        <p>
          Our team consists of professionals who are committed to delivering quality service, transparency, and simplicity. We believe in making complex challenges easier to navigate and providing the necessary resources to help you take control of your future. With SalarySathi, you can be confident that you’re in good hands.
        </p>
      </div>

      <div style={contentStyle} id="why-choose">
        <h2>Why Choose SalarySathi?</h2>
        <ul>
          <li><strong>Personalized Solutions:</strong> We understand that each individual and business has unique needs. That’s why we offer customized solutions that align with your specific circumstances and aspirations.</li>
          <li><strong>Reliability and Trust:</strong> SalarySathi is built on a foundation of trust and reliability. We prioritize customer satisfaction and strive to ensure that our services are dependable, always keeping your best interests at heart.</li>
          <li><strong>Expert Guidance:</strong> Our team of experts brings years of experience and knowledge to the table. Whether you're navigating new opportunities or facing challenges, we're here to offer you the guidance you need to succeed.</li>
          <li><strong>Commitment to Your Success:</strong> We are passionate about helping you achieve your objectives. From start to finish, we provide ongoing support to ensure you reach your full potential and succeed in your endeavors.</li>
          <li><strong>Easy Access and Convenience:</strong> With SalarySathi, accessing our services is quick and simple, allowing you to take action without unnecessary hassle. We make sure that everything is accessible and straightforward, so you can focus on what matters most.</li>
        </ul>
</div>

      <div style={contentStyle} id="contact">
        <h2>Contact Us</h2>
        <p><strong>Address:</strong> Basement, S-370, Malviya Nagar, Panchsheel Park, New Delhi, South West Delhi, Delhi 110017</p>
        <p><strong>Email:</strong> <a href="mailto:info@salarysaathi.com">info@salarysaathi.com</a></p>
        <p><strong>Mobile:</strong> <a href="tel:+918073605468">8073605468</a></p>
      </div>

      <footer style={footerStyle}>
        <p>&copy; 2024 SalarySathi. All Rights Reserved.</p>
      </footer>
    </div>
  );
}

// Inline styles (you can move this to an external CSS file)
const headerStyle = {
  background: '#5b6d5b',
  color: 'white',
  padding: '20px 0',
  textAlign: 'center',
  boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
};

const contentStyle = {
  maxWidth: '1200px',
  margin: '20px auto',
  color: 'black',  // Corrected property for text color
  padding: '30px',
  backgroundColor: '#ffffff', // Change this to a more visible color
  boxShadow: '0 8px 15px rgba(0, 0, 0, 0.2)',
  borderRadius: '12px',
};

const applyNowStyle = {
  textAlign: 'center',
  marginTop: '30px',
};

const buttonStyle = {
  background: '#5b6d5b',
  color: 'white',
  border: 'none',
  padding: '12px 25px',
  fontSize: '1.2rem',
  borderRadius: '25px',
  cursor: 'pointer',
  boxShadow: '0 4px 6px rgba(0, 0, 0, 0.2)',
  transition: 'background 0.3s ease',
};

const footerStyle = {
  background: '#5b6d5b',
  color: 'white',
  textAlign: 'center',
  padding: '15px 0',
  marginTop: '20px',
  boxShadow: '0 -4px 6px rgba(0, 0, 0, 0.1)',
};

export default App;
